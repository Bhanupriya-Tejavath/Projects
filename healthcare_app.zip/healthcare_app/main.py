from fastapi import FastAPI, UploadFile, File
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
import pandas as pd
import os

app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

UPLOAD_DIR = "uploads"
if not os.path.exists(UPLOAD_DIR):
    os.makedirs(UPLOAD_DIR)

data_df = None

@app.post("/upload")
async def upload_csv(file: UploadFile = File(...)):
    global data_df
    file_location = f"{UPLOAD_DIR}/{file.filename}"
    with open(file_location, "wb") as f:
        f.write(await file.read())
    data_df = pd.read_csv(file_location)
    return {"status": "uploaded", "columns": data_df.columns.tolist()}

@app.get("/stats")
def get_stats():
    global data_df
    if data_df is None:
        return JSONResponse(content={"error": "No file uploaded yet"}, status_code=400)
    stats = data_df.describe().to_dict()
    return stats

@app.get("/filter")
def filter_data(column: str, value: str):
    global data_df
    if data_df is None or column not in data_df.columns:
        return JSONResponse(content={"error": "Invalid column or data not uploaded"}, status_code=400)
    filtered = data_df[data_df[column].astype(str) == value]
    return filtered.to_dict(orient="records")

app.mount("/", StaticFiles(directory="frontend", html=True), name="static")
